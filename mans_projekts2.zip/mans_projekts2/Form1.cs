﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mans_projekts2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DateTime theDate;

            theDate = DateTime.Now;
            label3.Text = "Viktorīnas sākums: "+(theDate.ToString());
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 form2 = new Form2();
            form2.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Otrajā slaidā tev būs 6 jautājumi un spēles kauliņš.\n" +
                "Met kauliņu un kāds cipars izkritīs, atbildēsiet uz aktuālo jautājumu\r\n\r\nja nepareizi atbildēs - zaudēsi.\r\nJa atbildēs pareizi - uzvarēsi.\nŅemiet verā, ja Jūms nepatīk jautājums Jūs varat to nomainīt metot kauliņu vēlreiz!\r\nNu ko, sāksim!");
        }
    }
}
