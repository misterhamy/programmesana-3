﻿namespace mans_projekts2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labJautajums = new System.Windows.Forms.Label();
            this.picMetamaisKaulins = new System.Windows.Forms.PictureBox();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.butAtbilde3 = new System.Windows.Forms.Button();
            this.butAtbilde2 = new System.Windows.Forms.Button();
            this.butAtbilde1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picMetamaisKaulins)).BeginInit();
            this.SuspendLayout();
            // 
            // labJautajums
            // 
            this.labJautajums.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.labJautajums.ForeColor = System.Drawing.Color.Chocolate;
            this.labJautajums.Location = new System.Drawing.Point(12, 27);
            this.labJautajums.Name = "labJautajums";
            this.labJautajums.Size = new System.Drawing.Size(731, 40);
            this.labJautajums.TabIndex = 16;
            this.labJautajums.Text = "Jautājums:";
            // 
            // picMetamaisKaulins
            // 
            this.picMetamaisKaulins.Image = global::mans_projekts2.Properties.Resources.kaul;
            this.picMetamaisKaulins.Location = new System.Drawing.Point(643, 338);
            this.picMetamaisKaulins.Name = "picMetamaisKaulins";
            this.picMetamaisKaulins.Size = new System.Drawing.Size(100, 100);
            this.picMetamaisKaulins.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picMetamaisKaulins.TabIndex = 22;
            this.picMetamaisKaulins.TabStop = false;
            this.picMetamaisKaulins.Click += new System.EventHandler(this.picMetamaisKaulins_Click);
            // 
            // timer
            // 
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // butAtbilde3
            // 
            this.butAtbilde3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butAtbilde3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.butAtbilde3.Location = new System.Drawing.Point(16, 275);
            this.butAtbilde3.Name = "butAtbilde3";
            this.butAtbilde3.Size = new System.Drawing.Size(727, 48);
            this.butAtbilde3.TabIndex = 25;
            this.butAtbilde3.TabStop = false;
            this.butAtbilde3.Text = "3. atbilde";
            this.butAtbilde3.UseVisualStyleBackColor = true;
            this.butAtbilde3.Click += new System.EventHandler(this.butAtbilde3_Click);
            // 
            // butAtbilde2
            // 
            this.butAtbilde2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butAtbilde2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.butAtbilde2.Location = new System.Drawing.Point(16, 221);
            this.butAtbilde2.Name = "butAtbilde2";
            this.butAtbilde2.Size = new System.Drawing.Size(727, 48);
            this.butAtbilde2.TabIndex = 24;
            this.butAtbilde2.TabStop = false;
            this.butAtbilde2.Text = "2. atbilde";
            this.butAtbilde2.UseVisualStyleBackColor = true;
            this.butAtbilde2.Click += new System.EventHandler(this.butAtbilde2_Click);
            // 
            // butAtbilde1
            // 
            this.butAtbilde1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butAtbilde1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.butAtbilde1.Location = new System.Drawing.Point(16, 167);
            this.butAtbilde1.Name = "butAtbilde1";
            this.butAtbilde1.Size = new System.Drawing.Size(727, 48);
            this.butAtbilde1.TabIndex = 23;
            this.butAtbilde1.TabStop = false;
            this.butAtbilde1.Text = "1. atbilde";
            this.butAtbilde1.UseVisualStyleBackColor = true;
            this.butAtbilde1.Click += new System.EventHandler(this.butAtbilde1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.butAtbilde1);
            this.Controls.Add(this.butAtbilde3);
            this.Controls.Add(this.butAtbilde2);
            this.Controls.Add(this.picMetamaisKaulins);
            this.Controls.Add(this.labJautajums);
            this.Name = "Form2";
            this.Text = "Ko tu zini par pasauli?";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picMetamaisKaulins)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label labJautajums;
        private System.Windows.Forms.PictureBox picMetamaisKaulins;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Button butAtbilde3;
        private System.Windows.Forms.Button butAtbilde2;
        private System.Windows.Forms.Button butAtbilde1;
    }
}