﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mans_projekts2
{
    public partial class Form2 : Form
    {
        Random rand = new Random();
        int punkti;
        int reizes;
        public static int punkts = 0;
        public Form2()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            
        }

        private void picMetamaisKaulins_Click(object sender, EventArgs e)
        {
            reizes = 0;
            timer.Start();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            punkti = rand.Next(6) + 1;
            switch (punkti)
            {

                case 1: picMetamaisKaulins.Image = Properties.Resources.kaul;
                    labJautajums.Text = "Kurš ir visvairāk apdzīvotais valsts uz zemes?";
                    butAtbilde1.Text = "Monako";
                    butAtbilde2.Text = "Ķīna ";
                    butAtbilde3.Text = "Japāna";
                    break;

                case 2: picMetamaisKaulins.Image = Properties.Resources.kaul2;
                    labJautajums.Text = "Visnedraudzīgākā valsts pasaulē?";
                    butAtbilde1.Text = "Venecuēla ";
                    butAtbilde2.Text = "Krievija";
                    butAtbilde3.Text = "Bolīvija  ";
                    break;

                case 3: picMetamaisKaulins.Image = Properties.Resources.kaul3;
                    labJautajums.Text = "Lielākā pilsēta-valsts uz planētas?";
                    butAtbilde1.Text = "Singapūr ";
                    butAtbilde2.Text = "Monako ";
                    butAtbilde3.Text = "Vatikāns";
                    break;

                case 4: picMetamaisKaulins.Image = Properties.Resources.kaul4;
                    labJautajums.Text = "Kurā valstī tika izveidota Parīzes kopija?";
                    butAtbilde1.Text = "Ķīnā  ";
                    butAtbilde2.Text = "Vācijā";
                    butAtbilde3.Text = "Amerikā";
                    break;

                case 5: picMetamaisKaulins.Image = Properties.Resources.kaul5;
                    labJautajums.Text = "Uz kurām salām atrodas pasaulē lielākā zemūdens statuja?";
                    butAtbilde1.Text = "Kritā ";
                    butAtbilde2.Text = "Bahamu salās";
                    butAtbilde3.Text = "Kuka salās";
                    break;

                case 6: picMetamaisKaulins.Image = Properties.Resources.kaul6;
                    labJautajums.Text = "Sausākā valsts pasaulē?";
                    butAtbilde1.Text = "Lībija";
                    butAtbilde2.Text = "Čīle";
                    butAtbilde3.Text = "Sudāna";
                    break;
            }
            reizes++;
            if (reizes == 20)
            {
                timer.Stop();
            }
          

        }

        private void butAtbilde1_Click(object sender, EventArgs e)
        {
            if (punkti == 1) punkts++; 
            if (punkti == 2) punkts--;
            if (punkti == 3) punkts++;
            if (punkti == 4) punkts++;
            if (punkti == 5) punkts--;
            if (punkti == 6) punkts++;
            this.Hide();
            Form3 form3 = new Form3();
            form3.Show();
        }

        private void butAtbilde2_Click(object sender, EventArgs e)
        {
            if (punkti == 1) punkts--;
            if (punkti == 2) punkts--;
            if (punkti == 3) punkts--;
            if (punkti == 4) punkts--;
            if (punkti == 5) punkts++;
            if (punkti == 6) punkts--;

            this.Hide();
            Form3 form3 = new Form3();
            form3.Show();
        }

        private void butAtbilde3_Click(object sender, EventArgs e)
        {
            if (punkti == 1) punkts--;
            if (punkti == 2) punkts++;
            if (punkti == 3) punkts--;
            if (punkti == 4) punkts--;
            if (punkti == 5) punkts--;
            if (punkti == 6) punkts--;

            this.Hide();
            Form3 form3 = new Form3();
            form3.Show();

        }

    }
}
